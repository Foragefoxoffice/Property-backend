const asyncHandler = require("../utils/asyncHandler");
const ErrorResponse = require("../utils/errorResponse");
const PetPolicy = require("../models/PetPolicy");
const CreateProperty = require("../models/CreateProperty");

// @desc    Get all Pet Policies
// @route   GET /api/v1/petpolicy
exports.getPetPolicies = asyncHandler(async (req, res) => {
    const { page = 1, limit = 10 } = req.query;
    const skip = (page - 1) * limit;

    const petPolicies = await PetPolicy.find()
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(Number(limit));

    const total = await PetPolicy.countDocuments();

    res.status(200).json({
        success: true,
        count: petPolicies.length,
        total,
        page: Number(page),
        totalPages: Math.ceil(total / limit),
        data: petPolicies,
    });
});

// @desc    Create a new Pet Policy
// @route   POST /api/v1/petpolicy
exports.createPetPolicy = asyncHandler(async (req, res) => {
    const { code_en, code_vi, name_en, name_vi, status } = req.body;

    if (!code_en || !code_vi || !name_en || !name_vi) {
        throw new ErrorResponse("All English and Vietnamese fields are required", 400);
    }

    const existing = await PetPolicy.findOne({
        $or: [{ "code.en": code_en }, { "code.vi": code_vi }],
    });
    if (existing) {
        throw new ErrorResponse("Pet Policy code already exists", 400);
    }

    // ❌ Prevent duplicate name
    const existingName = await PetPolicy.findOne({
        $or: [
            { "name.en": { $regex: new RegExp(`^${name_en}$`, "i") } },
            { "name.vi": { $regex: new RegExp(`^${name_vi}$`, "i") } }
        ]
    });

    if (existingName) {
        throw new ErrorResponse("Pet Policy with this name already exists", 400);
    }

    const newPetPolicy = await PetPolicy.create({
        code: { en: code_en, vi: code_vi },
        name: { en: name_en, vi: name_vi },
        status: status || "Active",
    });

    res.status(201).json({
        success: true,
        message: "Pet Policy created successfully",
        data: newPetPolicy,
    });
});

// @desc    Update Pet Policy
// @route   PUT /api/v1/petpolicy/:id
exports.updatePetPolicy = asyncHandler(async (req, res) => {
    const { code_en, code_vi, name_en, name_vi, status } = req.body;

    const policy = await PetPolicy.findById(req.params.id);
    if (!policy) throw new ErrorResponse("Pet Policy not found", 404);

    // ❌ Prevent duplicate name on update
    if (name_en || name_vi) {
        const duplicateName = await PetPolicy.findOne({
            _id: { $ne: policy._id },
            $or: [
                { "name.en": { $regex: new RegExp(`^${name_en || policy.name.en}$`, "i") } },
                { "name.vi": { $regex: new RegExp(`^${name_vi || policy.name.vi}$`, "i") } }
            ]
        });

        if (duplicateName) {
            throw new ErrorResponse("Pet Policy with this name already exists", 400);
        }
    }

    policy.code.en = code_en ?? policy.code.en;
    policy.code.vi = code_vi ?? policy.code.vi;
    policy.name.en = name_en ?? policy.name.en;
    policy.name.vi = name_vi ?? policy.name.vi;
    policy.status = status ?? policy.status;

    await policy.save();

    res.status(200).json({
        success: true,
        message: "Pet Policy updated successfully",
        data: policy,
    });
});

// @desc    Delete Pet Policy
// @route   DELETE /api/v1/petpolicy/:id
exports.deletePetPolicy = asyncHandler(async (req, res) => {
    const policy = await PetPolicy.findById(req.params.id);
    if (!policy) throw new ErrorResponse("Pet Policy not found", 404);

    const isUsed = await CreateProperty.exists({
        $or: [
            { "propertyUtility.propertyUtilityUnitName.en": policy.name.en },
            { "propertyUtility.propertyUtilityUnitName.vi": policy.name.vi }
        ]
    });

    if (isUsed) {
        return res.status(400).json({
            success: false,
            message: "Cannot delete this master data because it is present in a created property. Delete the property first."
        });
    }

    await policy.deleteOne();

    res.status(200).json({
        success: true,
        message: "Pet Policy deleted successfully",
    });
});
