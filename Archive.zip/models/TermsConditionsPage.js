const mongoose = require("mongoose");

const termsConditionsPageSchema = new mongoose.Schema(
    {
        termsConditionBannerTitle_en: {
            type: String,
            required: false,
            trim: true,
            maxlength: 200,
        },
        termsConditionBannerTitle_vn: {
            type: String,
            required: false,
            trim: true,
            maxlength: 200,
        },
        termsConditionContentTitle_en: {
            type: String,
            required: false,
            trim: true,
            maxlength: 200,
        },
        termsConditionContentTitle_vn: {
            type: String,
            required: false,
            trim: true,
            maxlength: 200,
        },
        termsConditionContent_en: {
            type: String,
            required: false,
        },
        termsConditionContent_vn: {
            type: String,
            required: false,
        },
        termsConditionBannerImage: {
            type: String,
            required: false,
        },
        // New Flat SEO Fields
        seo: {
            focusKeyword: { type: String, default: "" },
            title: { type: String, default: "" },
            description: { type: String, default: "" },
            slug: { type: String, default: "" },
            canonicalUrl: { type: String, default: "" },
            noIndex: { type: Boolean, default: false },
        },
        // SEO Fields
        termsConditionSeoMetaTitle_en: { type: String, maxlength: 200 },
        termsConditionSeoMetaTitle_vn: { type: String, maxlength: 200 },
        termsConditionSeoMetaDescription_en: { type: String, maxlength: 500 },
        termsConditionSeoMetaDescription_vn: { type: String, maxlength: 500 },
        termsConditionSeoMetaKeywords_en: [{ type: String }],
        termsConditionSeoMetaKeywords_vn: [{ type: String }],
        termsConditionSeoSlugUrl_en: { type: String },
        termsConditionSeoSlugUrl_vn: { type: String },
        termsConditionSeoCanonicalUrl_en: { type: String },
        termsConditionSeoCanonicalUrl_vn: { type: String },
        termsConditionSeoSchemaType_en: { type: String },
        termsConditionSeoSchemaType_vn: { type: String },
        termsConditionSeoOgTitle_en: { type: String },
        termsConditionSeoOgTitle_vn: { type: String },
        termsConditionSeoOgDescription_en: { type: String },
        termsConditionSeoOgDescription_vn: { type: String },
        termsConditionSeoAllowIndexing: { type: Boolean, default: true },
        termsConditionSeoOgImage: { type: String, default: "" },
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model("TermsConditionsPage", termsConditionsPageSchema);
