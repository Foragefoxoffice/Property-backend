const mongoose = require('mongoose');

const permissionSchema = {
    hide: { type: Boolean, default: false },
    view: { type: Boolean, default: false },
    preview: { type: Boolean, default: false },
    edit: { type: Boolean, default: false },
    delete: { type: Boolean, default: false },
    add: { type: Boolean, default: false },
    copy: { type: Boolean, default: false },
    bulkUpload: { type: Boolean, default: false }
};

const roleSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Please add a role name'],
        unique: true,
        trim: true
    },
    status: {
        type: String,
        enum: ['Active', 'Inactive'],
        default: 'Active'
    },
    isApprover: {
        type: Boolean,
        default: false
    },
    permissions: {
        properties: {
            lease: permissionSchema,
            sale: permissionSchema,
            homestay: permissionSchema
        },
        cms: {
            homePage: permissionSchema,
            aboutUs: permissionSchema,
            contactUs: permissionSchema,
            header: permissionSchema,
            footer: permissionSchema,
            agent: permissionSchema, // Property Consultet
            termsConditions: permissionSchema,
            privacyPolicy: permissionSchema,
            blogBanner: permissionSchema
        },
        blogs: {
            category: permissionSchema,
            blogCms: permissionSchema,
            subscription: permissionSchema
        },
        userManagement: {
            userDetails: permissionSchema,
            enquires: permissionSchema
        },
        menuStaffs: {
            roles: permissionSchema,
            staffs: permissionSchema
        },
        otherEnquiry: {
            contactEnquiry: permissionSchema
        },
        landlords: permissionSchema,
        masters: permissionSchema,
        settings: {
            notification: permissionSchema,
            testimonials: permissionSchema
        }
    }
}, { timestamps: true });

module.exports = mongoose.model('Role', roleSchema);
